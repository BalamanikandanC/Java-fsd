package Phase1.PracticeProject3.AssistedPractice5;

public class LinkedList {
	static class Node{
		int data;
		Node next;
		public Node(int d) {
			this.data = d;
			next=null;
		}
	}
	Node head;
	static void insert(LinkedList list,int data) {
		Node newNode=new Node(data);
		if(list.head==null) {
			list.head=newNode;
		}
		else {
			Node last=list.head;
			while(last.next!=null) {
				last=last.next;
			}
			last.next=newNode;
		}

	}
	static void printlist(LinkedList list) {
		if(list.head==null)System.out.println("empty list");
		else {
			System.out.print("list: ");
			Node itr=list.head;
			while(itr.next!=null) {
				System.out.print(itr.data+" ");
				itr=itr.next;
			}
			System.out.println();
		}
	}

	static void deleteByKey(LinkedList list, int key) {
		Node currNode = list.head, prev = null; 
		if (currNode != null && currNode.data == key) 
		{ 
			list.head = currNode.next; // Changed head 
			System.out.println(key + " found and deleted"); 
		} 
		while (currNode != null && currNode.data != key) 
		{ 
			prev = currNode; 
			currNode = currNode.next; 
		} 
		if (currNode != null) 
		{ 
			prev.next = currNode.next; 
			System.out.println(key + " found and deleted"); 
		} 
		if (currNode == null) 
		{ 
			System.out.println(key + " not found"); 
		} 

	}

public static void main(String[] args) {
	// TODO Auto-generated method stub
	LinkedList list=new LinkedList();
	insert(list,1);
	insert(list,2);
	insert(list,3);
	insert(list,4);
	insert(list,5);
	insert(list,6);
	printlist(list);
	deleteByKey(list,2);
	printlist(list);
	deleteByKey(list,3);
	printlist(list);
	deleteByKey(list,7);
	printlist(list);

}

}

package Phase5AssistedProjectSet1.LocatingUsingCSSAndXpath;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class App 
{
    public static void main( String[] args ) throws InterruptedException
    {
    	//register the web driver =>browser vendor 
        WebDriverManager.chromedriver().setup();
        //creating an object to the object
        WebDriver wd=new ChromeDriver();
        //maximize the browser
        wd.manage().window().maximize();
        
        //go to browser and open this url 
        wd.get("https://www.saucedemo.com/");
        
        wd.findElement(By.cssSelector("input#user-name")).sendKeys("standard_user");
        Thread.sleep(1000);
        
        wd.findElement(By.cssSelector("input[name='password']")).sendKeys("secret_sauce");
        Thread.sleep(1000);
        
        wd.findElement(By.cssSelector("input.submit-button")).click();
        
        
        wd.findElement(By.xpath("/html/body/div/div/div/div[1]/div[1]/div[1]/div/div[1]/div/button")).click();
        Thread.sleep(1000);
        
        wd.findElement(By.xpath("//*[@id=\"react-burger-cross-btn\"]")).click();
        Thread.sleep(1000);
        
        wd.findElement(By.cssSelector("button.btn[name='add-to-cart-sauce-labs-backpack']")).click();
        Thread.sleep(1000);
    }
}

package com.example;

import java.util.List;

import org.springframework.orm.hibernate3.HibernateTemplate;

public class UserDAO {

	private HibernateTemplate temp;

	public void setTemp(HibernateTemplate temp) {
		this.temp = temp;
	}
	
	public int insert(User s) {
		return (int)temp.save(s);
	}
	public User getStudent(int Id) {
		return (User) temp.find("from User s where s.id=?",Id).stream().findFirst().orElse(null);
	}
	public void update(User s) {
		temp.update(s);
	}
	public List<User> getall(){
		return (List<User>)temp.find("from User");
	}
}

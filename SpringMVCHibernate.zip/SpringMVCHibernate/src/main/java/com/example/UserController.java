package com.example;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class UserController {

	@RequestMapping("/insert")
	public ModelAndView insert(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mv=new ModelAndView();
		ApplicationContext ac=new ClassPathXmlApplicationContext("spring.xml");
		User s=ac.getBean(User.class);
		UserDAO dao=ac.getBean(UserDAO.class);
		s.setSname(request.getParameter("name"));
		s.setSemail(request.getParameter("email"));
		if(dao.insert(s)>0) {
			mv.setViewName("success.jsp");
		}
		return mv;
	}
	@RequestMapping("/update")
	public ModelAndView update(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mv=new ModelAndView();
		ApplicationContext ac=new ClassPathXmlApplicationContext("spring.xml");
		User s=ac.getBean(User.class);
		UserDAO dao=ac.getBean(UserDAO.class);
		int Id=Integer.parseInt(request.getParameter("SId"));
		User user=dao.getStudent(Id);
		if(user!=null) {
				mv.setViewName("EditForm.jsp");
				mv.addObject("user",user);
			}
		else {
			mv.setViewName("ErrorPage.jsp");
		}
		return mv;
	}
	@RequestMapping("/Edit")
	public ModelAndView Edit(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mv=new ModelAndView();
		ApplicationContext ac=new ClassPathXmlApplicationContext("spring.xml");
		User s=ac.getBean(User.class);
		UserDAO dao=ac.getBean(UserDAO.class);
		s.setId(Integer.parseInt(request.getParameter("Id")));
		s.setSname(request.getParameter("NewName"));
		s.setSemail(request.getParameter("NewEmail"));
		dao.update(s);
		List<User> list=dao.getall();
		mv.setViewName("displayall.jsp");
		mv.addObject("list",list);
		return mv;
	}
	
	@RequestMapping("/getall")
	public ModelAndView getall(HttpServletRequest request,HttpServletResponse response) {
		ModelAndView mv=new ModelAndView();
		ApplicationContext ac=new ClassPathXmlApplicationContext("spring.xml");
		User user=ac.getBean(User.class);
		UserDAO dao=ac.getBean(UserDAO.class);
		List<User> list=dao.getall();
		mv.setViewName("displayall.jsp");
		mv.addObject("list",list);
		
		return mv;
	}

}

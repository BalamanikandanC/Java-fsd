package TypeCasting;

public class ImplicitExplicitTypeCasting {
	
	public static void main(String []args)
	{
		//Widening uses implicit type-casting
		System.out.println("Implicit Type Casting:");
		
		int a=10;
		System.out.println("The value of a: "+a);
		
		float b=a;
		System.out.println("The value of b: "+b);
		
		double c=a;
		System.out.println("The value of c: "+c+ "\n");
		
		//Narrowing uses explicit type-casting
		System.out.println("Explicit Type Casting");
	
		double d=20.2346789345;
		System.out.println("The value of d: "+d);
		
		int e=(int)d;
		System.out.println("The value of e: "+e);
		
		float f=(float)d;
		System.out.println("The value of f: "+f);
		
		short g=(short)d;
		System.out.println("The value of g: "+g);
	}
}

package Phase1.PracticeProject3.AssistedPractice4;

public class Matrix {
	static int[][] multiplyMatrices(int[][] A,int[][] B, int r1, int c1, int c2){
		int result[][]=new int[r1][c2];
		for(int i=0;i<r1;i++) {
			for(int j=0;j<c2;j++) {
				for(int k=0;k<c1;k++){
					result[i][j]+=A[i][k]*B[k][j];
				}
			}
		}
		return result;
	}
	static void displayProduct(int[][] product) {
		System.out.println("The product of the matrix: ");
		for(int[] row: product) {
			for(int e: row) {
				System.out.print(e+"  ");
			}
			System.out.println();
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int r1 = 2, c1 = 3;
		int r2 = 3, c2 = 2;
		int[][] firstMatrix = { {3, -2, 5}, {3, 0, 4} };
		int[][] secondMatrix = { {2, 3}, {-9, 0}, {0, 4} };
		if(c1!=r2)System.out.println("Multiplication not possible");
		else {
		int[][] product = multiplyMatrices(firstMatrix, secondMatrix, r1, c1, c2);
		displayProduct(product);
		}


	}

}

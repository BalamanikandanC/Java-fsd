package com.example;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import io.github.bonigarcia.wdm.WebDriverManager;

public class NewTest {
    private WebDriver wd;   
    SoftAssert soft=new SoftAssert();
    @Test               
    public void testEasy() {     
        String title = wd.getTitle();                
        soft.assertEquals("FB Login",title);        
    }   
    @BeforeTest
    public void beforeTest() {  
    	//register the web driver =>browser vendor 
        WebDriverManager.chromedriver().setup();
        //creating an object to the object
        wd=new ChromeDriver();
        //maximize the browser
        wd.manage().window().maximize();
        
        //go to browser and open this url 
        wd.get("https://www.facebook.com");
    }       
    @AfterTest
    public void afterTest() {
        wd.quit();          
    }   

}

package TestNg.AutomateWebAppTestNG;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import io.github.bonigarcia.wdm.WebDriverManager;

public class WebAppTest {
WebDriver wd=null;
String errorMessage="";
SoftAssert sa=new SoftAssert();
	
	@BeforeTest
	public void initiate() {
				//register the webdriver =>browser vendor 
				WebDriverManager.chromedriver().setup();
				//creating an object to the object
				wd=new ChromeDriver();
				//maximize the browser
				wd.manage().window().maximize();
	}
	
	@Test
	  public void Test1() throws InterruptedException {

		System.out.println("test1 User Not Found Test");
		wd.get("http://localhost:4200/signin");
		wd.findElement(By.name("email")).sendKeys("Admin");
        Thread.sleep(1000);
        wd.findElement(By.name("password")).sendKeys("Admin@123");
        Thread.sleep(1000);
        wd.findElement(By.cssSelector("#loginButton")).click();
        Thread.sleep(1000);
        errorMessage=wd.findElement(By.cssSelector("#message")).getText();
        sa.assertEquals("*Login Failed (User not found)", errorMessage);
		sa.assertAll();//provide all the issues at the last

	  }
	
	@Test
	  public void Test2() throws InterruptedException {

		System.out.println("test2 Invalid Password Test");
		wd.get("http://localhost:4200/signin");
		wd.findElement(By.name("email")).sendKeys("Admin@c.c");
        Thread.sleep(1000);
        wd.findElement(By.name("password")).sendKeys("Admin@");
        Thread.sleep(1000);
        wd.findElement(By.cssSelector("#loginButton")).click();
        Thread.sleep(1000);
        errorMessage=wd.findElement(By.cssSelector("#message")).getText();
        Assert.assertEquals("*Login Failed (Invalid Password)", errorMessage);
		sa.assertAll();//provide all the issues at the last

	  }
	
	@Test
	  public void Test3() throws InterruptedException {

		System.out.println("test3 Other Login Exception Test");
		wd.get("http://localhost:4200/signin");
		wd.findElement(By.name("email")).sendKeys("");
        Thread.sleep(1000);
        wd.findElement(By.name("password")).sendKeys("Admin@123");
        Thread.sleep(1000);
        wd.findElement(By.cssSelector("#loginButton")).click();
        Thread.sleep(1000);
        errorMessage=wd.findElement(By.cssSelector("#message")).getText();
        sa.assertEquals("*Login Failed", errorMessage);
		sa.assertAll();//provide all the issues at the last

	  }
	
	@Test
	  public void Test4() throws InterruptedException {

		System.out.println("test4 Success Login Test");
		wd.get("http://localhost:4200/signin");
		wd.findElement(By.name("email")).sendKeys("Admin@c.c");
        Thread.sleep(1000);
        wd.findElement(By.name("password")).sendKeys("Admin@123");
        Thread.sleep(1000);
        wd.findElement(By.cssSelector("#loginButton")).click();
        Thread.sleep(1500);
        String Heading=wd.findElement(By.id("message")).getText();
        System.out.println(Heading);
        Thread.sleep(1000);
        sa.assertEquals("Register Student", Heading);
		sa.assertAll();//provide all the issues at the last

	  }
	
	@Test
	  public void Test5() throws InterruptedException {

		System.out.println("test5 Success Registration Test");
		wd.get("http://localhost:4200/signin");
		Thread.sleep(1000);
		wd.findElement(By.xpath("/html/body/app-root/app-login/div/div/div/p/button")).click();
        
        wd.findElement(By.id("inputName3")).sendKeys("Mani");
        Thread.sleep(500);
        wd.findElement(By.id("inputEmail3")).sendKeys("Mani@c.c");
        Thread.sleep(500);
        wd.findElement(By.id("inputPassword3")).sendKeys("Mani@123");
        Thread.sleep(500);
        wd.findElement(By.xpath("/html/body/app-root/app-register-login/div/div/div[2]/div/div[2]/form/div[5]/button[1]")).click();
        errorMessage=wd.findElement(By.xpath("/html/body/app-root/app-register-login/div/div/div[2]/div/div[2]/form/div[4]/div/h4")).getText();
        Thread.sleep(1000);
        System.out.println(errorMessage);
        sa.assertEquals("Registration successfull...!", errorMessage);
        Thread.sleep(2000);
        wd.findElement(By.xpath("/html/body/app-root/app-register-login/div/div/div[2]/div/div[2]/form/div[5]/button[2]")).click();
        Thread.sleep(2000);
		sa.assertAll();//provide all the issues at the last

	  }
	
	
	
	@AfterTest
	  public void close() {
		  wd.close();
	  }
}

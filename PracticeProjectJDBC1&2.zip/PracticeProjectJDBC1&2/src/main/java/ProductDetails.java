

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ecommerce.DBConnection;

/**
 * Servlet implementation class ProductDetails
 */
@WebServlet("/ProductDetails")
public class ProductDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProductDetails() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
        out.println("<html><body>");
        Connection conn= DBConnection.dbConn();
		out.println("DB Connection initialized.<br>");
		Statement st = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
        String id=request.getParameter("productId");
        
        int productId=Integer.parseInt(id);
        ResultSet rs=st.executeQuery("Select * from eproduct where ID="+productId+";");
        out.println("Executed an select query<br>");
        boolean flag=true;
        while(rs.next()) {  //1st row of the table
			out.print("ProductId:"+rs.getInt("ID")+", ");
			out.print("ProductName:"+rs.getString("name")+", ");
			out.print("ProductPrice:"+rs.getInt("price")+"<br>");
			flag=false;
		}
        if(flag) {
	    	out.println("No such product id found: ");
	    	rs=st.executeQuery("Select ID from eproduct ");
	    	out.println("Available product ID are: ");
	    	while(rs.next()) {
	    		out.println(rs.getInt("ID"));
	        }
    	}
        out.println("Executed an retrieveal operation<br>");
        out.println("</body></html>");
		}catch (ClassNotFoundException e) {
            e.printStackTrace();
    } catch (SQLException e) {
            e.printStackTrace();
    }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.Vector;

public class JavaCollections {
	public static void main(String[] args) {
		//creating Arraylist
		System.out.println("ArrayList");
		ArrayList<Integer>list=new ArrayList<Integer>();
		list.add(1);
		list.add(2);
		list.add(1, 3);
		System.out.println(list);
		Collections.sort(list);
		System.out.println("sorted ArrayList: "+ list);
		System.out.println();
		
		//creating Vector
		System.out.println("Vector");
		Vector<Integer>vec=new Vector<Integer>();
		vec.add(10);
		vec.add(20);
		vec.add(30);
		System.out.println(vec);
		System.out.println();
		
		//creating linkedList
		System.out.println("LinkedList");
		LinkedList<String>ll=new LinkedList<String>();
		ll.add("Bala");
		ll.add("Mani");
		ll.add("kandan");
		Iterator<String> itr=ll.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		System.out.println();
		
		//creating HashSet
		System.out.println("HashSet");
		HashSet<String>hs=new HashSet<String>();
		hs.add("Bala");
		hs.add("Bala");
		hs.add("mani");
		hs.add("kandan");
		hs.add("mani");
		System.out.println(hs);
		System.out.println();
		
		//creating linkedHashSet
		System.out.println("LinkedHashSet");
		LinkedHashSet<Integer>lhs=new LinkedHashSet<Integer>();
		lhs.add(11);
		lhs.add(22);
		lhs.add(11);
		lhs.add(33);
		System.out.println(lhs);
		System.out.println();
		
		//creating HashMap
		System.out.println("HashMap");
		HashMap<String,Integer>hm=new HashMap<String,Integer>();
		hm.put("Bala",1);
		hm.put("mani",2);
		hm.put("vinoth",3);
		System.out.println(hm);
	}

}

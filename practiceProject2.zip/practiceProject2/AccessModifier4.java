package practiceProject2;
import pack1.publicAndProaccessSpecifier;

public class AccessModifier4 extends publicAndProaccessSpecifier{
public static void main(String []args) {
	System.out.println("Protected Access-Specifier");
	AccessModifier4 obj=new AccessModifier4();
	obj.print();
	}
}

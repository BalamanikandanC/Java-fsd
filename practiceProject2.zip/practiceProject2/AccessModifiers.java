package practiceProject2;

class DefaultAccessSpecifier{
	void print() {
		System.out.println("This is Default Access-Specifier");
	}
}

public class AccessModifiers {
	public static void main(String []args)
	{
        System.out.println("Default Access-Specifier");
        DefaultAccessSpecifier obj= new DefaultAccessSpecifier();
        obj.print();
	}
}

package practiceProject2;
import pack1.*;

import pack1.publicAndProaccessSpecifier;

public class AccessModifier3 {
	public static void main(String []args) {
		System.out.println("Public Access-Specifier");
		publicAndProaccessSpecifier obj =new publicAndProaccessSpecifier();
		obj.display();
	}
}

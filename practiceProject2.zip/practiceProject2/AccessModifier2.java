package practiceProject2;
class PrivateAccessSpecifier{
	private void print() {
		System.out.println("Accessing method of another class");
	}
	
}
public class AccessModifier2 {

	private void print() {
		System.out.println("Accessing method within same class");
	}
	public static void main(String []args) {
		System.out.println("Private Access-Specifier");
		AccessModifier2 obj=new AccessModifier2();
		obj.print();
		try {
		PrivateAccessSpecifier pobj=new PrivateAccessSpecifier();
		pobj.print();
		}
		catch(Exception e)
		{
			System.out.println("private method of another class is not accessible");
			System.out.println(e);
		}
	}

}

package constructors;

public class DefaultConstructor {
	int a;
	String s;

	public static void main(String[] args) {
		// default constructor is called implicitly by java when object is created
		DefaultConstructor obj=new DefaultConstructor();
		System.out.println("The value of a is: "+ obj.a);
		System.out.println("The value of s is: "+ obj.s);
	}

}

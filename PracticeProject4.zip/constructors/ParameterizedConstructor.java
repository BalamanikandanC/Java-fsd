package constructors;

public class ParameterizedConstructor{
	private int a;
	private String b;
	ParameterizedConstructor(int a, String b){
		this.a=a;
		this.b=b;
	}
	
	@Override
	public String toString() {
		return "ParameterizedConstructor [a=" + a + ", b=" + b + "]";
	}

	public static void main(String []args)
	{
		ParameterizedConstructor obj =new ParameterizedConstructor(10, "Balamanikandan C");
		System.out.println(obj);
		
	}
	
	
}

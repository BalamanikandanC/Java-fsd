package constructors;

public class NonParameterizedConstructor {
	int a;
	String b;
	NonParameterizedConstructor(){
		a=10;
		b="Balamanikandan C";
	}
	public static void main(String[] args) {
		//Non-parameterized constructor
		NonParameterizedConstructor obj =new NonParameterizedConstructor();
		System.out.println("the value of a: "+obj.a);
		System.out.println("the value of b: "+obj.b);
	}
}

package methods;

public class CallByValueMethod {
	int value=100;
	public int changevalue(int change) {
		return value+=change;
	}
	public static void main(String[] args) {
		CallByValueMethod obj =new CallByValueMethod();
		System.out.println("before calling method: "+obj.value);
		obj.changevalue(100);
		System.out.println("before calling method: "+obj.value);
	}
}

package methods;

public class MethodSample {
	public String AnotherMethod() {
		return "This is another method calling from main";
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MethodSample obj=new MethodSample();
		System.out.println(obj.AnotherMethod());
	}

}

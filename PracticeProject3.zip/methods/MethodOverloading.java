package methods;

public class MethodOverloading {
	public void area(int side) {
		System.out.println("Area of square: "+ (side*side));
	}
	public void area(int length,int breadth) {
		System.out.println("Area of Rectangle: "+ (length*breadth));
	}
public static void main(String[] args) {
	//method overloading 
	MethodOverloading obj=new MethodOverloading();
	obj.area(10);
	obj.area(5,4);
}
}

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import java.util.TreeMap;

public class MapImplementation {

	public static void main(String[] args) {
		//creating HashMap
		System.out.println("HashMap");
		HashMap<String,Integer>hm=new HashMap<String,Integer>();
		hm.put("Bala",1);
		hm.put("mani",2);
		hm.put("vinoth",3);
		System.out.println("Rank of Bala: "+hm.get("Bala"));
		for(Map.Entry m:hm.entrySet()) {
			System.out.println(m.getKey()+"->"+m.getValue());
		}
		System.out.println();

		//creating HashTable
		System.out.println("HashTable");
		Hashtable<Integer,String>ht=new Hashtable<Integer,String>();
		ht.put(1, "java");
		ht.put(2, "python");
		ht.put(3, "C");
		System.out.println("No. 1 contains "+ht.get(1));
		for(Map.Entry m:ht.entrySet()) {
			System.out.println(m.getKey()+"->"+ m.getValue());
		}
		System.out.println();

		//creating TreeMap
		System.out.println("TreeMap");
		TreeMap<Integer,String>tm=new TreeMap<Integer,String>();
		tm.put(4, "HTML");
		tm.put(5,"CSS");
		tm.put(6, "JavaScript");
		System.out.println("No. 5 contains "+tm.get(5));
		for(Map.Entry m: tm.entrySet()) {
			System.out.println(m.getKey()+"->"+m.getValue());
		}
	}

}

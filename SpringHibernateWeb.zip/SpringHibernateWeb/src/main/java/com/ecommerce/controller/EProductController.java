package com.ecommerce.controller;

import com.ecommerce.entity.EProductEntity;

@Controller
public class EProductController {

        @Autowired
            private EProductService eproductService;
            @RequestMapping(value = "/productList", method = RequestMethod.GET)
            public String listProducts(ModelMap map)
            {
                map.addAttribute("eproduct", new EProductEntity());
                map.addAttribute("productList", eproductService.getAllProducts());
                return "productList";
            }
}


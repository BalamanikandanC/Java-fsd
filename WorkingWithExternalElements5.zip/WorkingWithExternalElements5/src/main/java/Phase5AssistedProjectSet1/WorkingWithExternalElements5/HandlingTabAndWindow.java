package Phase5AssistedProjectSet1.WorkingWithExternalElements5;

import java.util.Set;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class HandlingTabAndWindow {

public static void main(String args[]) {
	//register the webdriver =>browser vendor 
			WebDriverManager.chromedriver().setup();
			//creating an object to the object
			WebDriver driver=new ChromeDriver();
			//maximize the browser
			driver.manage().window().maximize();
	driver.get("https://www.google.com"); // Open the first tab

	// Open a new tab using JavaScript (example)
	((JavascriptExecutor)driver).executeScript("window.open('https://www.youtube.com','_blank');");

	// Get handles of all windows or tabs
	Set<String> windowHandles = driver.getWindowHandles();

	// Switch to the new window or tab
	for (String handle : windowHandles) {
	    driver.switchTo().window(handle);
	    System.out.println("Switched to window with title: " + driver.getTitle());
	    
	    // Perform actions on the current window/tab
	    // For example, get the URL
	    String currentURL = driver.getCurrentUrl();
	    System.out.println("Current URL of the window: " + currentURL);
	    
	    // Close the current window or tab
	    // driver.close(); // You can close the window/tab if needed
	}

	// Switch back to the first window or tab
	String firstWindowHandle = windowHandles.iterator().next();
	driver.switchTo().window(firstWindowHandle);
	System.out.println("Switched back to the first window with title: " + driver.getTitle());
}
}

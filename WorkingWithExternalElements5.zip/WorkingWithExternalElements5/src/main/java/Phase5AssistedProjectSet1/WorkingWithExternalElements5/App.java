package Phase5AssistedProjectSet1.WorkingWithExternalElements5;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.safari.SafariDriver.WindowType;

import io.github.bonigarcia.wdm.WebDriverManager;

public class App 
{
    public static void main( String[] args ) throws InterruptedException
    {
    	//register the webdriver =>browser vendor 
		WebDriverManager.chromedriver().setup();
		//creating an object to the object
		WebDriver wd=new ChromeDriver();
		//maximize the browser
		wd.manage().window().maximize();

		//webpage timebound 

		// wd.manage().timeouts().pageLoadTimeout(1,TimeUnit.MILLISECONDS);

		//go to browser and open this url 
		wd.get("https://demo.automationtesting.in/Alerts.html");
		wd.findElement(By.linkText("Alert with OK & Cancel")).click();
		Thread.sleep(500);
		wd.findElement(By.xpath("//*[@id=\"CancelTab\"]/button")).click();
		Thread.sleep(500);
		Alert alert=wd.switchTo().alert();
		System.out.println(alert.getText());
		Thread.sleep(1000);
		alert.accept();
		//alert.dismiss();
		Thread.sleep(1000);
		wd.findElement(By.linkText("Alert with Textbox")).click();
		Thread.sleep(500);
		wd.findElement(By.xpath("//*[@id=\"Textbox\"]/button")).click();
		Thread.sleep(500);
		Alert alert1=wd.switchTo().alert();
		alert1.sendKeys("Bala");
		Thread.sleep(1000);
		System.out.println(alert1.getText());
		alert1.accept();
		Thread.sleep(2000);
		wd.findElement(By.linkText("Alert with OK")).click();
		Thread.sleep(500);
		wd.findElement(By.xpath("//*[@id=\"OKTab\"]/button")).click();
		Thread.sleep(500);
		Alert alert2=wd.switchTo().alert();
		Thread.sleep(500);
		alert2.dismiss();
		Thread.sleep(2000);
		wd.close();
    }
}

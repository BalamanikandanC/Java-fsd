import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteAadhaarRequestComponent } from './delete-aadhaar-request.component';

describe('DeleteAadhaarRequestComponent', () => {
  let component: DeleteAadhaarRequestComponent;
  let fixture: ComponentFixture<DeleteAadhaarRequestComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [DeleteAadhaarRequestComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(DeleteAadhaarRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

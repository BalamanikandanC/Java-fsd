export class Admin{
    email:string;
    password:string;
    constructor() {
        this.email = '';
        this.password = '';
      }
}
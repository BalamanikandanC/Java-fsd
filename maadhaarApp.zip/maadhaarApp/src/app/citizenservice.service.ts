import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Citizen } from './Citizen';


@Injectable({
  providedIn: 'root'
})
export class CitizenserviceService {
  constructor(private http:HttpClient) { }

  public postCitizen(citizen:any){
    return this.http.post("http://localhost:8088/citizen",citizen,{responseType:'text' as 'json'});
  }

  public findCitizenBycID(cId:any){
    return this.http.get("http://localhost:8088/getCitizenBycID/"+cId);
  }

  public getCitizen(id:any){
    return this.http.get("http://localhost:8088/getCitizenByID/"+id);
  }

  public getCitizenToDeleted(state:boolean):Observable<any>{
    return this.http.get("http://localhost:8088/getCurrentCitizen/"+state);
  }

  public getNewAadhaarIssue():Observable<any>{
    return this.http.get("http://localhost:8088/getNewAadhaarIssue/");
  }

  public deleteCitizen(id:any):Observable<any>{
    return this.http.delete("http://localhost:8088/deleteCitizen/"+id);
  }
  public deleteUpdate(id:any):Observable<any>{
    return this.http.put <Citizen[]>("http://localhost:8088/updateDelete/"+id,{});
  }

  public updateIssued(id:any):Observable<any>{
    return this.http.put <Citizen[]>("http://localhost:8088/updateIssued/"+id,{});
  }

  public updateCitizen(id:any,citizen:any):Observable<any>{
    console.log(citizen.name);
    return this.http.put <Citizen[]>("http://localhost:8088/updateCitizen/"+id,citizen,{})
  }

  public applicationUpdate(id:any):Observable<any>{
    return this.http.put<Citizen[]>("http://localhost:8088/updateApplication/"+id,{});
  }

  public duplicationUpdate(id:any):Observable<any>{
    return this.http.put<Citizen[]>("http://localhost:8088/updateDuplicate/"+id,{});
  }

  public getAllCitizen():Observable<any>{
    return this.http.get<any[]>("http://localhost:8088/getAllCitizens");
  }
}

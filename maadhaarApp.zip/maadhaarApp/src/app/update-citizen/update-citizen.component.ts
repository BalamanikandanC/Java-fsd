import { Component } from '@angular/core';
import { CitizenserviceService } from '../citizenservice.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-update-citizen',
  templateUrl: './update-citizen.component.html',
  styleUrl: './update-citizen.component.css'
})
export class UpdateCitizenComponent {
id=""
citizen:any[]=[]
citizens:any[]=[]
name=""
dob=""
address=""
email=""
gender=""
mobile=""
cID=""
passport=""
message=""
  constructor(private citizenService:CitizenserviceService,private route:ActivatedRoute,private router:Router){
  
  }

  ngOnInit():void{
    this.route.paramMap.subscribe(params=>{
      const idParam=params.get('id');
      this.id+=idParam;
    })

    this.getemployee(this.id);

  }
  getemployee(id:any){
    this.citizenService.getCitizen(id).subscribe(cit=>{this.citizen.push(cit)});
  }

  updatecitizen(name:string,dob:string,address:string,email:string,
    gender:string,mobileNo:string,citizenId:string,passportNo:string){
      name=name.trim();
      console.log(name);
      dob=dob.trim();
      address=address.trim();
      email=email.trim();
      gender=gender.trim();
      mobileNo=mobileNo.trim();
      citizenId=citizenId.trim();
      passportNo=passportNo.trim();
      const citizen={name,dob,address,email,gender,mobileNo,citizenId,passportNo};
      this.citizenService.updateCitizen(this.id,citizen).subscribe(newCitizen=>{this.citizens.push(citizen)});
      this.message="Citizen "+name+" is Updated Successfully!!";
      alert(this.message);
      this.router.navigate(['/citizen/'+citizenId]);
    }
}

import { Admin } from './Admin';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AdminserivceService {
  constructor(private http:HttpClient) { }

  public postAdminCredentials(admin:any){
    return this.http.post("http://localhost:8088/admin",admin,{responseType:'text' as 'json'});
  }

  public findAdminByemail(email:any){
    return this.http.get("http://localhost:8088/findByemail/"+email);
  }
}

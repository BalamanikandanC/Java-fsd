import { Component } from '@angular/core';
import { CitizenserviceService } from '../citizenservice.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-all-aadhaar',
  templateUrl: './all-aadhaar.component.html',
  styleUrl: './all-aadhaar.component.css'
})
export class AllAadhaarComponent {
  citizens:any[]=[];

  constructor(private citizenService:CitizenserviceService,private route:ActivatedRoute,private router:Router){}
  ngOnInit():void{
    this.getAllCitizen();
  }
getAllCitizen():void{
  this.citizenService.getAllCitizen().subscribe(
    citizens => {
        this.citizens = citizens;
        console.log(this.citizens); // Log the data here to check if it's retrieved correctly
    },
    error => {
        console.error('Error during getAllCitizen:', error);
    }
);
  console.log(this.citizens.length);
}

}

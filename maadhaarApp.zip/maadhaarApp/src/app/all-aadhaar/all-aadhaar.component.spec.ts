import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AllAadhaarComponent } from './all-aadhaar.component';

describe('AllAadhaarComponent', () => {
  let component: AllAadhaarComponent;
  let fixture: ComponentFixture<AllAadhaarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AllAadhaarComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AllAadhaarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

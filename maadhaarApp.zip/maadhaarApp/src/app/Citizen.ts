export class Citizen{
    name:string;
    dob:any;
    address:string;
    email:string;
    mobileNo:string;
    gender:string;
    aadhaarNo:string;
    citizenId:string;
    passportNo:string;
    applicationDate:any;
    issueDate:any;
    approvalStatus:string;
    duplicate:boolean;
    isDeleted:boolean;

    constructor() {
        this.name='';
        this.dob='';
        this.address='';
        this.email='';
        this.mobileNo='';
        this.gender='';
        this.aadhaarNo='0';
        this.citizenId='';
        this.passportNo='';
        this.applicationDate='0';
        this.issueDate='0';
        this.approvalStatus='0';
        this.duplicate=false;
        this.isDeleted=false;
      }
}

import { NgModule, Component } from '@angular/core';
import { BrowserModule, provideClientHydration } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule, Routes } from '@angular/router';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { CitizenLoginComponent } from './citizen-login/citizen-login.component';
import { CitizenDashboardComponent } from './citizen-dashboard/citizen-dashboard.component';
import { RegisterNewUserComponent } from './register-new-user/register-new-user.component';
import { UpdateCitizenComponent } from './update-citizen/update-citizen.component';
import { AllAadhaarComponent } from './all-aadhaar/all-aadhaar.component';
import { NewAadhaarRequestComponent } from './new-aadhaar-request/new-aadhaar-request.component';
import { DeleteAadhaarRequestComponent } from './delete-aadhaar-request/delete-aadhaar-request.component';

const routes:Routes=[
  {path:"adminlogin",component:LoginComponent},
  {path:"admin",component:AdminDashboardComponent},
  {path:"",component:CitizenLoginComponent},
  {path:"citizenlogin",component:CitizenLoginComponent},
  {path:"citizen/:id",component:CitizenDashboardComponent},
  {path:"register",component:RegisterNewUserComponent},
  {path:"update/:id",component:UpdateCitizenComponent},
  {path:"allAadhaar",component:AllAadhaarComponent},
  {path:"newrequest",component:NewAadhaarRequestComponent},
  {path:"deleterequest",component:DeleteAadhaarRequestComponent}
]
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    AdminDashboardComponent,
    CitizenLoginComponent,
    CitizenDashboardComponent,
    RegisterNewUserComponent,
    UpdateCitizenComponent,
    AllAadhaarComponent,
    NewAadhaarRequestComponent,
    DeleteAadhaarRequestComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    RouterModule.forRoot(routes)
  ],
  providers: [
    provideClientHydration()
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }

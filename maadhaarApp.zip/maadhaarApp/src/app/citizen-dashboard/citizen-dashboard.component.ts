import { Citizen } from './../Citizen';
import { Component } from '@angular/core';
import { CitizenserviceService } from '../citizenservice.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-citizen-dashboard',
  templateUrl: './citizen-dashboard.component.html',
  styleUrl: './citizen-dashboard.component.css'
})
export class CitizenDashboardComponent {
citizenId=""
citizen:any[]=[]
Citizens:any[]=[]
response=''
  constructor(private citizenService:CitizenserviceService,private route:ActivatedRoute,private router:Router){}
  ngOnInit():void{
    this.route.paramMap.subscribe(params=>{
      const idParam=params.get('id');
      this.citizenId+=idParam;
    })

    this.getcitizen(this.citizenId);
  }

  getcitizen(id:any){
    this.citizenService.findCitizenBycID(id).subscribe(citi=>{this.citizen.push(citi)});
  }

  isdelete(id:any){
    this.citizenService.deleteUpdate(id).subscribe( (citizens: Citizen[]) => {
      // Handle the response here, citizens is the updated list
      console.log('Response from updateDelete:', citizens);
    },
    error => {
      // Handle error
      console.error('Error during updateDelete:', error);
    }
  );
    alert("Delete Request made successfully");
  }

  isapplied(id:any){
    this.citizenService.applicationUpdate(id).subscribe( (citizens: Citizen[]) => {
      // Handle the response here, citizens is the updated list
      console.log('Response from applicationUpdate:', citizens);
    },
    error => {
      // Handle error
      console.error('Error during applicationUpdate:', error);
    }
  );
    alert("New Aadhaar Request made successfully");
  }

  isduplicate(id:any){
    this.citizenService.duplicationUpdate(id).subscribe( (citizens: Citizen[]) => {
      // Handle the response here, citizens is the updated list
      console.log('Response from duplicateUpdate:', citizens);
    },
    error => {
      // Handle error
      console.error('Error during duplicateUpdate:', error);
    }
  );
    alert("Duplicate Aadhaar Request made successfully");
  }

}

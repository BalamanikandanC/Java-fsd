import { Component } from '@angular/core';
import { CitizenserviceService } from '../citizenservice.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Citizen } from '../Citizen';

@Component({
  selector: 'app-new-aadhaar-request',
  templateUrl: './new-aadhaar-request.component.html',
  styleUrl: './new-aadhaar-request.component.css'
})
export class NewAadhaarRequestComponent {
  citizens:any[]=[];

  constructor(private citizenService:CitizenserviceService,private route:ActivatedRoute,private router:Router){}
  ngOnInit():void{
    this.getNewAadhaaIssue();
  }
  getNewAadhaaIssue():void{
  this.citizenService.getNewAadhaarIssue().subscribe(
    citizens => {
        this.citizens = citizens;
        console.log(this.citizens); // Log the data here to check if it's retrieved correctly
    },
    error => {
        console.error('Error during getAllCitizen:', error);
    }
);
}

issueAadhaar(id:any){
  const userConfirmed = window.confirm('Are you sure you want to issue Aadhaar for this citizen?');
  if(userConfirmed){
  this.citizenService.updateIssued(id).subscribe((citizens: Citizen[]) => {
    // Handle the response here, citizens is the updated list
    console.log('Response from Issuing New Aadhaar:', citizens);
  },
  error => {
    // Handle error
    console.error('Error during Issuing New Aadhaar:', error);
  })
}
}
}

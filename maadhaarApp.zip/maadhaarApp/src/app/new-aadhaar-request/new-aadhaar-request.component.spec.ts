import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NewAadhaarRequestComponent } from './new-aadhaar-request.component';

describe('NewAadhaarRequestComponent', () => {
  let component: NewAadhaarRequestComponent;
  let fixture: ComponentFixture<NewAadhaarRequestComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [NewAadhaarRequestComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(NewAadhaarRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

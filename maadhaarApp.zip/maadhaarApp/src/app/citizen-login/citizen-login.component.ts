import { Component } from '@angular/core';
import { Citizen } from '../Citizen';
import { ActivatedRoute, Router } from '@angular/router';
import { CitizenserviceService } from '../citizenservice.service';

@Component({
  selector: 'app-citizen-login',
  templateUrl: './citizen-login.component.html',
  styleUrl: './citizen-login.component.css'
})
export class CitizenLoginComponent {
  citizen:Citizen=new Citizen();
  message="";
  cID="";
  password="";

  constructor(private service:CitizenserviceService,private route:ActivatedRoute,private router:Router){}
    ngOnInit():void{

    }

    validateLogin(cID: string, password: string) {
      console.log(cID);
      this.service.findCitizenBycID(cID).subscribe(
         (data: any) => {
          if (data!=null) {
            this.citizen = data; // Assuming data contains an array of users matching the email
            if (this.citizen.mobileNo === password) {
              this.router.navigate(['/citizen/'+cID]);
            } else {
              this.message = "*Login Failed (Invalid Password)";
            }
          } else {
            this.message = "*Login Failed (User not found)";
          }
        },
        (error) => {
          console.error('Error occurred: ', error);
          this.message = "*Login Failed";
        }
      );
    }
}

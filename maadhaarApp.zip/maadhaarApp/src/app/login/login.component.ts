import { Component } from '@angular/core';
import { Admin } from '../Admin';
import { AdminserivceService } from '../adminserivce.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {

  admin:Admin=new Admin();
  message="";
  email="";
  password="";

  constructor(private service:AdminserivceService,private route:ActivatedRoute,private router:Router){}
    ngOnInit():void{

    }

    validateLogin(email: string, password: string) {
      this.service.findAdminByemail(email).subscribe(
         (data: any) => {
          if (data!=null) {
            this.admin = data; // Assuming data contains an array of users matching the email
            if (this.admin.password === password) {
              this.router.navigate(['/admin']);
            } else {
              this.message = "*Login Failed (Invalid Password)";
            }
          } else {
            this.message = "*Login Failed (User not found)";
          }
        },
        (error) => {
          console.error('Error occurred: ', error);
          this.message = "*Login Failed";
        }
      );
    }

}

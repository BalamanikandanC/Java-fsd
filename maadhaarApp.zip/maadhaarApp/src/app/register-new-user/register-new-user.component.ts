import { CitizenserviceService } from './../citizenservice.service';
import { Component } from '@angular/core';

@Component({
  selector: 'app-register-new-user',
  templateUrl: './register-new-user.component.html',
  styleUrl: './register-new-user.component.css'
})
export class RegisterNewUserComponent {
citizens:any[]=[];
id=""
name=""
dob=""
address=""
email=""
gender=""
mobile=""
cID=""
passport=""
message=""
constructor(private citizenService:CitizenserviceService){}
ngOnInit():void{}

addcitizen(name:string,dob:string,address:string,email:string,
  gender:string,mobileNo:string,citizenId:string,passportNo:string){
    name=name.trim();
    dob=dob.trim();
    address=address.trim();
    email=email.trim();
    gender=gender.trim();
    mobileNo=mobileNo.trim();
    citizenId=citizenId.trim();
    passportNo=passportNo.trim();
    const citizen={name,dob,address,email,gender,mobileNo,citizenId,passportNo,};
    this.citizenService.postCitizen(citizen).subscribe(newCitizen=>{this.citizens.push(citizen)});
    this.message="Citizen "+name+" is Registered Successfully!!";
    alert(this.message);
  }

}

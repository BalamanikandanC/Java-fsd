
public class StringImplementation {
	public static void main(String[] args) {
		//string Methods
		String str= "Hellow world";
		System.out.println("length: "+str.length());
		System.out.println("substring: "+str.substring(7));
		System.out.println("toUpperCase: "+str.toUpperCase());
		System.out.println("toLowerCase: "+str.toLowerCase());
		String s1="Welcome",s2="All";
		String str2=s1.concat(s2);
		System.out.println("concatenate:"+str2);
		System.out.print("equals:");
		System.out.println(str.equals(str2));
		System.out.print("compareTo");
		System.out.println(str.compareTo(str2));
		System.out.println();
		
		//StringBuffer
		System.out.println("StringBuffer");
		String s="Hello";
		StringBuffer sbr=new StringBuffer(s);
		sbr.append("world");
		System.out.println(sbr);
		sbr.insert(0, 'H');
		System.out.println(sbr);
		sbr.delete(0, 4);
		System.out.println(sbr);
		sbr.reverse();
		System.out.println(sbr);
		System.out.println();
		
		//StringBuilder
		System.out.println("StringBuffer");
		StringBuilder sb1=new StringBuilder("Welcome");
		sb1.append("Home");
		System.out.println(sb1);
		System.out.println(sb1.delete(0, 1));
		System.out.println(sb1.insert(1, "Hello"));
		System.out.println(sb1.reverse());
		
		//conversion
		String str3="Bala";
		StringBuilder sb=new StringBuilder(str3);
		sb.reverse();
		System.out.println(sb.toString());
		
		StringBuffer sbr1=new StringBuffer("happening");
		sbr1.append("Now");
		System.out.println(sbr1);

		
		
		
		
	}
}

package com.railwayCrossing.dao;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.railwayCrossing.dbutil.DbUtil;
import com.railwayCrossing.pojo.Admin;

public class AdminDAO {
	public Admin getAdmin(String AdminEmail) {
		Session session=DbUtil.dbConn();
		Transaction transaction=session.beginTransaction();
		Query<Admin> query=session.createQuery("from Admin a where a.AdminEmail=:aEmail",Admin.class);
		query.setParameter("aEmail", AdminEmail);
		Admin userAdmin=null;
		userAdmin=query.getSingleResult();
		transaction.commit();
		session.close();
		return userAdmin;
	}
}

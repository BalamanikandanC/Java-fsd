package com.railwayCrossing.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.railwayCrossing.dbutil.DbUtil;
import com.railwayCrossing.pojo.User;

public class UserDAO {
	public int addUser(User user) {
		Session session=DbUtil.dbConn();
		Transaction trans=session.beginTransaction();
		int value=(Integer) session.save(user);
		trans.commit();
		session.close();
		return value;
	}
	public List<User> display(){
		Session session=DbUtil.dbConn();
		Transaction transaction=session.beginTransaction();
		Query<User> query=session.createQuery("from User",User.class);
		List<User> list=null;
		list=query.list();
		transaction.commit();
		session.close();
		return list;
	}
	public User getUser(int id) {
		Session session=DbUtil.dbConn();
		Transaction transaction=session.beginTransaction();
		Query<User> query=session.createQuery("from User t where t.ID=:tid",User.class);
		query.setParameter("tid", id);
		User user=query.getSingleResult();
		transaction.commit();
		session.close();
		return user;
	}
	public User getUser(String UserMail) {
		Session session=DbUtil.dbConn();
		Transaction transaction=session.beginTransaction();
		Query<User> query=session.createQuery("from User t where t.Email=:uMail",User.class);
		query.setParameter("uMail", UserMail);
		User user=query.getSingleResult();
		transaction.commit();
		session.close();
		return user;
	}
	public void update(User user) {
		Session session=DbUtil.dbConn();
		Transaction transaction=session.beginTransaction();
		session.update(user);
		transaction.commit();
		session.close();
		return ;
	}
	public void delete(User user) {
		Session session=DbUtil.dbConn();
		Transaction transaction=session.beginTransaction();
		session.delete(user);
		transaction.commit();
		session.close();
		return ;
	}
}

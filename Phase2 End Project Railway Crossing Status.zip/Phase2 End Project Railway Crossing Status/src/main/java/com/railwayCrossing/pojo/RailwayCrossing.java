package com.railwayCrossing.pojo;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class RailwayCrossing {
@Id
@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int ID;
	private String Name;
	private String Address;
	private String LandMark;
	private String TrainSchedule;
	private String PersonInCharge;
	private String status;
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public String getLandMark() {
		return LandMark;
	}
	public void setLandMark(String landMark) {
		LandMark = landMark;
	}
	public String getTrainSchedule() {
		return TrainSchedule;
	}
	public void setTrainSchedule(String trainSchedule) {
		TrainSchedule = trainSchedule;
	}
	public String getPersonInCharge() {
		return PersonInCharge;
	}
	public void setPersonInCharge(String personInCharge) {
		PersonInCharge = personInCharge;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
}



import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.railwayCrossing.dao.RailwayCrossingDAO;
import com.railwayCrossing.pojo.RailwayCrossing;
/**
 * Servlet implementation class CrossingController
 */
public class CrossingController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CrossingController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RailwayCrossingDAO dao= new RailwayCrossingDAO();
		RailwayCrossing rc=new RailwayCrossing();
		rc.setName(request.getParameter("Name"));
		rc.setAddress(request.getParameter("Address"));
		rc.setLandMark(request.getParameter("Landmark"));
		rc.setTrainSchedule(request.getParameter("Schedule"));
		rc.setPersonInCharge(request.getParameter("Incharge"));
		rc.setStatus("Open");
		int row=dao.addCrossing(rc);
		if(row>0) {
			response.sendRedirect("adminHome.jsp");
		}
	}

}

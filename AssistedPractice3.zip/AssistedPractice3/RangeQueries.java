package Phase1.PracticeProject3.AssistedPractice3;

public class RangeQueries {
	static int[]arr;
	static int rangeQuery(int l, int r) {
		int sum=0;
		for(int i=l;i<=r;i++)
		{
			sum+=arr[i];
		}
		return sum;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		arr=new int[] {3,7,2,5,8,9};
		System.out.println(rangeQuery(0,5));
		System.out.println(rangeQuery(3,5));
		System.out.println(rangeQuery(1,2));

	}

}

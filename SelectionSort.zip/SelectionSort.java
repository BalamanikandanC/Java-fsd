import java.util.Arrays;

public class SelectionSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Selection Sort");
		int A[]=new int[] {9,8,7,6,5,4,3,2,1};
		int n=A.length;
		int min;
		for(int i=0;i<n-1;i++) {
			min=i;
			for(int j=i+1;j<n;j++) {
				
				if(A[j]<A[min]) {
					min=j;
				}
			}
			A[i]=(A[i]+A[min])-(A[min]=A[i]);
		}
       System.out.println(Arrays.toString(A));
	}

}

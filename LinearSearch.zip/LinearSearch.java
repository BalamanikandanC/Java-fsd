import java.util.Scanner;

public class LinearSearch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]=new int[] {5,4,3,2,1,6,7,8,9};
		System.out.println("Linear Search");
		System.out.println("Enter the element you want to search: ");
		Scanner sc=new Scanner(System.in);
		int key=sc.nextInt();
		int i;
		for(i=0;i<a.length;i++) {
			if(a[i]==key) {
				break;
			}
		}
		if(i<a.length) {
			System.out.println("Element found at "+i);
		}
		else System.out.println("Element not found");
	}

}

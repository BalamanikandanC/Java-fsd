package com.ecommerce.controllers;

public interface ProductRepository {

}

package Phase1.PracticeProject3.AssistedPractice1;

import java.util.Arrays;

public class RotateArray {
	static void rotateArrayFiveStep(int[] arr, int n) {
		int temp=0;
		for(int i=0;i<5;i++)
		{
			temp=arr[n-1];
			for(int j=n-2;j>=0;j--) {
				arr[j+1]=arr[j];
			}
			arr[0]=temp;
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]=new int [] {1,2,3,4,5,6,7};
		System.out.println("Before rotation: "+ Arrays.toString(arr));
		rotateArrayFiveStep(arr,arr.length);
		System.out.println("After rotation: "+ Arrays.toString(arr));
		

	}

}

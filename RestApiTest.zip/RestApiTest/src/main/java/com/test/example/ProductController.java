package com.test.example;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(path="/webapi")
public class ProductController {

	@Autowired
	ProductService service;
	
	@RequestMapping("/allproduct")
	public List<ProductEntity>getAllProduct(){
		return service.getAllProduct();
	}
	
	@RequestMapping("/product/{id}")
	public ProductEntity getProduct(@PathVariable int id) {
		return service.getProduct(id);
	}
	
	@RequestMapping(value="/product", method=RequestMethod.POST)
	public void addProduct(@RequestBody ProductEntity pe) { 
		service.addProduct(pe);
	}
	
	@RequestMapping(value="/product/{id}", method=RequestMethod.PUT)
	public void updateProduct(@PathVariable int id,@RequestBody ProductEntity pe) {
		service.updateProduct(id, pe);
	}
	
	@RequestMapping(value="/product/{id}",method=RequestMethod.DELETE)
	public void deleteProduct(@PathVariable int id) {
		service.deleteProduct(id);
	}
}

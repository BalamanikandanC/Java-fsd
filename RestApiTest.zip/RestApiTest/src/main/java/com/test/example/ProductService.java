package com.test.example;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProductService {
	@Autowired
	ProductRepository repo;
	
	public List<ProductEntity>getAllProduct(){
		return repo.findAll();
	}
	
	public ProductEntity getProduct(int id){
		return repo.findById(id).get();
	}
	
	public void addProduct(ProductEntity pe) {
		repo.save(pe);
	}
	
	public void updateProduct(int id,ProductEntity pe) {
		if(repo.findById(id).isPresent()) {
			ProductEntity oldProductEntity=repo.findById(id).get();
			oldProductEntity.setName(pe.getName());
			oldProductEntity.setDescription(pe.getDescription());
			repo.save(oldProductEntity);
		}
	}
	
	public void deleteProduct(int id) {
		repo.deleteById(id);
	}

}

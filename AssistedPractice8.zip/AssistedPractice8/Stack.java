package Phase1.PracticeProject3.AssistedPractice8;

import java.util.Scanner;

public class Stack {
	final static int MAX=1000;
	int top;
	int a[]=new int[MAX];
	Stack() {
		top=-1;
	}
	boolean isEmpty() {
		return(top<0);
	}
	void push(int value) {
		if(top>MAX) {
			System.out.println("Stack Overflow");
		}
		else {
			a[++top]=value;
			System.out.println("pushed into stack");
		}
	}
	int pop() {
		if(top<0) {
			System.out.println("Stack Underflow");
			return 0;
		}
		else {
			return a[top--];
		}

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Stack stack=new Stack();
		Scanner scanner=new Scanner(System.in);
		boolean quit=false;
		while (true) {
		      System.out.print("Enter 1 to push, 2 to pop, 3 to quit: ");
		      int choice = scanner.nextInt();

		      switch (choice) {
		        case 1:
		          System.out.print("Enter a value to push: ");
		          int value = scanner.nextInt();
		          stack.push(value);
		          break;
		        case 2:
		          int popvalue = stack.pop();
		          System.out.println("The value popped is: " + popvalue);
		          break;
		        case 3:
		          System.out.println("Quitting...");
		          quit=true;
		          break;
		        default:
		          System.out.println("Invalid choice!");
		      }
		      if(quit)break;
		    }

	}

}

package Phase1.PracticeProject3.AssistedPractice6;

public class LinkedList {
	static class Node{
		int data;
		Node next;
		Node(int data){
			this.data=data;
			next=null;
		}
	}
	Node head;
	static void sortedInsert(LinkedList list,int data) {
		Node newNode=new Node(data);
		Node currNode=list.head;
		if(currNode==null) {
			newNode.next=newNode;
			list.head=newNode;
			
		}
		else if(currNode.data>=newNode.data) {
			while (currNode.next != list.head) 
    			currNode = currNode.next; 
	currNode.next = newNode; 
			newNode.next = list.head; 
			list.head = newNode; 
		}
		else {
			while (currNode.next != list.head && currNode.next.data < newNode.data) 
				currNode = currNode.next; 
			newNode.next = currNode.next; 
	currNode.next = newNode; 

		}
	}
	static void printlist(LinkedList list) {
		if (list.head != null) 
   		{ 
        			Node temp = list.head; 
        			do
       			{ 
            			System.out.print(temp.data + " "); 
            			temp = temp.next; 
        			}  while (temp != list.head); 
    		} 

		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList list=new LinkedList();
		sortedInsert(list,2);
		sortedInsert(list,11);
		sortedInsert(list,5);
		sortedInsert(list,7);
		sortedInsert(list,15);
		printlist(list);
		

	}

}

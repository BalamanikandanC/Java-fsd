package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = "com.ecommerce.controllers")
public class AssistedPractice2Set21Application {

	public static void main(String[] args) {
		SpringApplication.run(AssistedPractice2Set21Application.class, args);
	}

}

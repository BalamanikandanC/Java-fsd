
public class ThreadRunnable implements Runnable {
	public static int i=0;
	
	public ThreadRunnable(){
		
	}
	
	public void run() {
        	for(int j=0;i<10;j++)
            try{
                System.out.println("Expl Thread: "+ (++i));
                Thread.sleep(100);
            } catch (InterruptedException iex) {
                System.out.println("Exception in thread: "+iex.getMessage());
            }

    } 


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("starting thread");
		ThreadRunnable tr=new ThreadRunnable();
		Thread t=new Thread(tr);
		t.start();
		for(int k=0;i<10;k++) {
			try{
                System.out.println("Main Thread: "+ (i+=2));
                Thread.sleep(100);
            } catch (InterruptedException iex) {
                System.out.println("Exception in main thread: "+iex.getMessage());
            }
		}
		System.out.println("ending thread");
	}

}

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Arrays;
import java.util.List;

public class CreateFile {
	private static void fileClassMethod() throws IOException {
		File file=new File("C://Users//balam//Documents//workspace-spring-tool-suite-4-4.20.0.RELEASE//Practice-Project2//test.text");
				if(file.createNewFile()) {
					System.out.println("File created");
				}
				else System.out.println("File already Exist");
			FileWriter writer =new FileWriter("C://Users//balam//Documents//workspace-spring-tool-suite-4-4.20.0.RELEASE//Practice-Project2//test.text");
			writer.write("learning java in simplilearn");
			writer.close();
	}
	private static void FileOutputStreamClass() throws IOException
    {
        String data = "Test data";
        FileOutputStream out = new FileOutputStream("C://Users//balam//Documents//workspace-spring-tool-suite-4-4.20.0.RELEASE//Practice-Project2//test2.text");
        out.write(data.getBytes());
        out.close();
    }
	private static void createFileIn_NIO()  throws IOException
    {
        String data = "Test data";
        Files.write(Paths.get("C://Users//balam//Documents//workspace-spring-tool-suite-4-4.20.0.RELEASE//Practice-Project2//test3.text"), data.getBytes());
        List<String> lines = Arrays.asList("1st line", "2nd line");
       Files.write(Paths.get("file6.txt"),lines,
                    StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE,
                    StandardOpenOption.APPEND);
    }

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		fileClassMethod();
		FileOutputStreamClass();
		createFileIn_NIO();
		
	}

}

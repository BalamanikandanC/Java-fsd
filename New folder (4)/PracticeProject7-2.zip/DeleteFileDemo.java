import java.io.IOException;
import java.nio.file.DirectoryNotEmptyException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Paths;

public class DeleteFileDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try
        { 
            Files.deleteIfExists(Paths.get("C://Users//balam//Documents//workspace-spring-tool-suite-4-4.20.0.RELEASE//Practice-Project2//test2.text")); 
        } 
        catch(NoSuchFileException e) 
        { 
            System.out.println("No such file/directory exists"); 
        } 
        catch(DirectoryNotEmptyException e) 
        { 
            System.out.println("Directory is not empty."); 
        } 
        catch(IOException e) 
        { 
            System.out.println("Invalid permissions."); 
        } 
          
        System.out.println("Deletion successful."); 
    } 


	}


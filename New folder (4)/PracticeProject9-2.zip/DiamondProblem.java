interface classA{
	default void show(){
		System.out.println("ClassA");
	}
}
interface classB{
	default void show(){
		System.out.println("ClassB");
	}
}
public class DiamondProblem implements classA,classB{
	public void show() {
		classA.super.show();
		classB.super.show();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DiamondProblem dp=new DiamondProblem();
		dp.show();
	}

}


public class SleepWait {
	private static Object obj =new Object();
	
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.out.println("Thread going to sleep");
		Thread.sleep(3000);
		System.out.println("Thread woke up afer 1 second");
		 synchronized(obj) {
			 System.out.println("Thread will wait for notify");
			 obj.wait(3000);
		 }
		 System.out.println("Thread will woken up after timeout");
		
	}

}

class MyException extends Exception{
	String s;
	MyException(String s){
		this.s=s;
	}
	public String toString() {
		return("My Exception Occured:"+s);
	}
}
public class ExceptionHandler {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			System.out.println("I am throwing exception");
			throw new MyException("This is my Exception");
		}catch(MyException e) {
			System.out.println(e.toString());
		}

	}

}

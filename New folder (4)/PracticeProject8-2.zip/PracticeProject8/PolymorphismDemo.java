package PracticeProject8;

public class PolymorphismDemo {
	 private final static double PI=3.14;
	private double area(double radius) {
		return PI*radius*radius;
	}
	private  double area(double length,double breadth) {
		return length*breadth;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PolymorphismDemo pd=new PolymorphismDemo();
		System.out.println("area of circle "+ pd.area(5.5));
		System.out.println("area of rectangle "+ pd.area(2.5,3));
		
	}

}

package PracticeProject8;

class Employee{
	public int ID;
	public String Name;
	public double Salary;
	public Employee(int iD, String name, double salary) {
		ID = iD;
		Name = name;
		Salary = salary;
	}
	public int getID() {
		return ID;
	}
	public String getName() {
		return Name;
	}
	public double getSalary() {
		return Salary;
	}
	@Override
	public String toString() {
		return "Employee [ID=" + ID + ", Name=" + Name + ", Salary=" + Salary + "]";
	}
	
}

public class EncapsulationDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee emp=new Employee(1,"bala",10000);
		System.out.println("EmpId:" + emp.getID());
		System.out.println("EmpName:" + emp.getName());
		System.out.println("EmpSalary:" + emp.getSalary());
		System.out.println(emp.toString());
	}
}

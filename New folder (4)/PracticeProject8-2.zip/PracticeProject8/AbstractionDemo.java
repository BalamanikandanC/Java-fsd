package PracticeProject8;

abstract class Shape{
	abstract double area();
	public abstract String toString();
	
}
class Circle extends Shape{
	private final static double PI=3.14;
	double radius;
	public Circle(double radius) {
		this.radius = radius;
	}

	@Override
	double area() {
		
		return PI*radius*radius;
	}

	@Override
	public
	String toString() {
		return "The area of Circle"+area();
	}
	
}
public class AbstractionDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Shape s1=new Circle(5.5);
		System.out.println(s1.area());
		System.out.println(s1.toString());
	}

}

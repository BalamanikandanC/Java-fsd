package PracticeProject8;
class Student{
	String Name;
	String departmentName;
	int studentID;
	public Student(String name, String departmentName, int studentID) {
		Name = name;
		this.departmentName = departmentName;
		this.studentID = studentID;
	}
	public String getName() {
		return Name;
	}
	public String getDepartmentName() {
		return departmentName;
	}
	public int getStudentID() {
		return studentID;
	}
	@Override
	public String toString() {
		return "Student [Name=" + Name + ", departmentName=" + departmentName + ", studentID=" + studentID + "]";
	}
	
}

public class ClassAndObjectDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student student=new Student("bala","java",80137);
		System.out.println(student.toString());
		
	}

}

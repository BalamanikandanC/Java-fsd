package PracticeProject8;


class Bike{
	int speed=200;
}
class R15 extends Bike{
	int speed=300;
	void speedOfr15() {
		System.out.println(speed+120);
	}
}
class yamaha extends R15{
	int speed=300;
	void speedOfr15() {
		System.out.println(super.speed+120);
	}
}

public class InheritanceDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		yamaha y=new yamaha();
		y.speedOfr15();
	}

}

class customException extends Exception{
	public customException(String s) {
		super(s);
	}
}
public class CustomExceptionDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       try {
    	   throw new customException("My Exception");
       }catch(customException e) {
    	   System.out.println(e.getMessage());
       }
	}

}

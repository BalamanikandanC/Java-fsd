
public class ThrwoableDemo {
	public static void ThrowableException() throws Exception {
		
		throw new Exception("New Exception Thrwon");
	}

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
        try {
        	   ThrowableException();
        	}catch(Throwable e) {
        		System.out.println("Exception: "+e.getMessage());
        	}

}
}

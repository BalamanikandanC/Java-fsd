import java.util.InputMismatchException;
import java.util.Scanner;

public class ThrowDemo {

	public static void main(String[] args) {
		int a=10,b=0;
		try {
			if(b==0)throw(new InputMismatchException("can't divide by zero"));
			else System.out.println("result is: "+(a/b));
		}catch(InputMismatchException e)
		{
			System.out.println("Erro:"+e.getMessage());
		}
	}

}


public class FinallyDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			int a=10/0;
			System.out.println(a);
		}catch(Exception e) {
			System.out.println("can't divide by zero");
		}
		finally {
			System.out.println("result is: Infinity");
		}

	}

}

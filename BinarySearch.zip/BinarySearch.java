import java.util.Scanner;

public class BinarySearch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]=new int[] {1,6,7,8,9};
		System.out.println("Binary Search");
		System.out.println("Enter the element you want to search: ");
		Scanner sc=new Scanner(System.in);
		int key=sc.nextInt();
		int l=0,r=a.length-1;
		int mid;
		while(l<=r)
		{
			mid=l+(r-l)/2;
			if(a[mid]==key) {
				System.out.println("Element found at"+ mid);
				break;
			}
			else if(key<a[mid])r=mid-1;
			else l=mid+1;
		}
		if(l>r)System.out.println("Element not found");
	}

}

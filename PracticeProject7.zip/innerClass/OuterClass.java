package innerClass;

public class OuterClass {
	private int d=10;
	class Inner{
		void display() {
			System.out.println("value of data d is: "+d);
		}
	}

	public static void main(String[] args) {
		// Member Inner class : A class created within class and outside method.
		OuterClass obj=new OuterClass();
		OuterClass.Inner in =obj.new Inner();
		in.display();
	}

}

package innerClass;

abstract class food{
	abstract void make();
}
public class AnnonymousInnerClass {

	public static void main(String[] args) {
		// Anonymous Inner Class: A class created for implementing an interface or extending class
		food f=new food() {
			void make() {
				System.out.println("Biriyani");
			}
		};
		f.make();
	}
}

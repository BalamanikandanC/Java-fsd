package innerClass;

public class InnerClass {
	private int d=10;
	void display()
	{
		class Local
		{
			void show() 
			{
				System.out.println("data member: "+d);
			}
		}
		
		Local l=new Local();
		l.show();
	}

	public static void main(String[] args) {
		// Local Inner Class
		InnerClass obj=new InnerClass();
		obj.display();
	}

}

package innerClass;

public class StaticClass {

	static int d=10;
	static class Inner{
		void show() {
			System.out.println("data member: "+d);
		}
	}
	public static void main(String[] args) {
		// Static class
		StaticClass.Inner obj=new StaticClass.Inner();
		obj.show();
	}

}

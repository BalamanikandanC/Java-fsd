package Phase1.PracticeProject3.AssistedPractice2;

import java.util.Arrays;

public class FourthSmallestElement {

	static int kthSmallestElement(int[] arr, int n, int k) {
		if(k<0 || k>=n)return Integer.MAX_VALUE;
		else {
		for(int i=0;i<k;i++)
		{
			for(int j=0;j<n-1-i;j++) {
				if(arr[j]<arr[j+1]) {
					swap(arr,j,j+1);
				}
			}
			System.out.println(Arrays.toString(arr));
		}
		return arr[n-k];
		}
		
	}
	static void swap(int[] arr, int x,int y) {
		int temp=arr[x];
		arr[x]=arr[y];
		arr[y]=temp;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]=new int[] {1,2,3,4,5,6,7};
		int k=4;
		int n=arr.length;
		System.out.println("The fourth smallest element is :"+ kthSmallestElement(arr,n,k));

	}

}

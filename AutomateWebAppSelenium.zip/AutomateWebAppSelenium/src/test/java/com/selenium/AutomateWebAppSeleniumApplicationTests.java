package com.selenium;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutomateWebAppSeleniumApplicationTests {

	@Test
	void contextLoads() {
	}

}

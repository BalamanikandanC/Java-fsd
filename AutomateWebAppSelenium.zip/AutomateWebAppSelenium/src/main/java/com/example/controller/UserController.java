package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.pojo.User;

@RestController
@CrossOrigin(origins = "*")//for all external networks we can use hitting this requests 
public class UserController {

	@Autowired
	UserRepo repo;
	
	//insert
		@PostMapping("/register")
		public String register(@RequestBody User user) {
			repo.save(user);
			return "Hi "+user.getName()+" is registered successfully...!";
			
		}

}

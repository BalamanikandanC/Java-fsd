import java.util.Arrays;

public class InsertionSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Insertion Sort");
		int A[]=new int[] {9,8,7,6,5,4,3,2,1};
		int n=A.length;
		for(int i=0;i<n;i++) {
			int temp=A[i];
			int j=i;
			while(j>0 && temp<A[j-1]) {
				A[j]=A[j-1];
				j=j-1;
			}
			A[j]=temp;
		}
		System.out.println(Arrays.toString(A));
	}

}

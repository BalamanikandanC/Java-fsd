package Phase5AssistedProjectSet1.LocatingWebPageElement2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class App 
{
    public static void main( String[] args ) throws InterruptedException
    {//register the web driver =>browser vendor 
        WebDriverManager.chromedriver().setup();
        //creating an object to the object
        WebDriver wd=new ChromeDriver();
        //maximize the browser
        wd.manage().window().maximize();
        
        //go to browser and open this url 
        wd.get("https://www.saucedemo.com/");
        
        wd.findElement(By.id("user-name")).sendKeys("standard_user");
        Thread.sleep(1000);
        
        wd.findElement(By.xpath("//*[@id=\"password\"]")).sendKeys("secret_sauce");
        Thread.sleep(1000);
        
        wd.findElement(By.name("login-button")).click();
        
        
        wd.findElement(By.xpath("/html/body/div/div/div/div[1]/div[1]/div[1]/div/div[1]/div/button")).click();
        Thread.sleep(1000);
        
        wd.findElement(By.className("bm-cross-button")).click();
        
        Thread.sleep(2000);
    }
}

package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Phase6mAadhaarApplication {

	public static void main(String[] args) {
		SpringApplication.run(Phase6mAadhaarApplication.class, args);
	}

}

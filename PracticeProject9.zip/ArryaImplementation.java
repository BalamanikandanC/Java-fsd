import java.util.Scanner;

public class ArryaImplementation {

	public static void main(String[] args) {
		// Array Implementation
		Scanner s=new Scanner(System.in);
		int arr[]= new int[] {1,2,3,4};
		for(int i: arr)
		{
			System.out.println("array elements: "+i);
		}
		int arr2[][]=new int[2][2];
		System.out.println("Two dimensional arrya");
		for(int i=0;i<2;i++)
		{
			for(int j=0;j<2;j++)
			{
				System.out.println("enter element value:");
				arr2[i][j]=s.nextInt();
			}
		}
		System.out.println("Length of row 1: "+arr2[0].length );
		

	}

}

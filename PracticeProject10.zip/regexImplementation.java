import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class regexImplementation {

	public static void main(String[] args) {
		Pattern p = Pattern.compile(".s");
		Matcher m = p.matcher("aas");  
		boolean b = m.matches();  
		  
		
		boolean b2=Pattern.compile(".s").matcher("es").matches();  
		  
		
		boolean b3 = Pattern.matches(".s", "aaaas");  
		  
		System.out.println(b+" "+b2+" "+b3);  

	}

}

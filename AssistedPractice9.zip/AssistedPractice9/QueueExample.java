package Phase1.PracticeProject3.AssistedPractice9;

import java.util.LinkedList;
import java.util.Queue;

public class QueueExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Queue<Integer>queue=new LinkedList<>();
		queue.add(2);
		queue.add(3);
		queue.add(4);
		System.out.println("Queue is : " + queue);
		System.out.println("Head of Queue : " + queue.peek());
		queue.remove();
		System.out.println("After removing Head of Queue : " + queue);
		System.out.println("Size of Queue : " + queue.size());
	}

}
